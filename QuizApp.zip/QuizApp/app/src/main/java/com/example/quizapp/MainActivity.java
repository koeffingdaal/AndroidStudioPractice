package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {
    private Button yes;
    private Button no;
    private TextView question;

    private static final String[] questions = {"Is Java a person?", "Is apple a fruit?",
    "Dhaka is capital of BD?","Do we have 206 bones?"};

    private static final boolean[] answers = {false,true,true,true};
    private int index = 0;
    private int score = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        yes = findViewById(R.id.buttonYes);
        no = findViewById(R.id.buttonNo);
        question = findViewById(R.id.textViewQuestion);
        question.setText(questions[index]);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (index < questions.length){
                    if (answers[index]){
                        score++;
                    }
                    index++;
                    if (index < questions.length){
                        question.setText(questions[index]);
                    }else {
                        Toast.makeText(MainActivity.this, "Your Score is" + score, Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "Restart the App to play Again!", Toast.LENGTH_SHORT).show();
                }


            }
            
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (index < questions.length){
                    if (!answers[index]){
                        score++;
                    }
                    index++;
                    if (index < questions.length){
                        question.setText(questions[index]);
                    }else {
                        Toast.makeText(MainActivity.this, "Your Score is" + score, Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(MainActivity.this, "Restart the App to play Again!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}